from __future__ import annotations

import argparse
import json
import time
from collections import defaultdict
from itertools import islice
from pathlib import Path

import torch
from torch.nn import functional as F
from torch.utils.data import DataLoader
from tqdm.auto import tqdm

from ..config import load_config
from ..data import SentinelPatchDataset
from ..metrics import basic_metrics
from ..models.system import GeoDiffGAN
from ..training.checkpoint import load_checkpoint
from .evaluate import _device_summary, _duration, _resolve_device


def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate bicubic and base-branch baselines")
    parser.add_argument("--config", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--base-checkpoint")
    parser.add_argument("--split", default="test")
    parser.add_argument("--limit", type=int)
    parser.add_argument("--device", choices=("auto", "cuda", "cpu"), default="auto")
    parser.add_argument(
        "--progress",
        choices=("compact", "tqdm", "quiet"),
        default="compact",
    )
    parser.add_argument("--optional-metrics", action="store_true", help=argparse.SUPPRESS)
    args = parser.parse_args()

    config = load_config(args.config)
    device = _resolve_device(args.device)
    amp_enabled = bool(
        device.type == "cuda"
        and config.get("training", {}).get("amp", True)
    )
    if device.type == "cuda":
        torch.backends.cudnn.benchmark = True
    print(f"[baselines] device={_device_summary(device)}", flush=True)
    print(f"[baselines] amp={amp_enabled}", flush=True)
    print(f"[baselines] loading {args.split} dataset", flush=True)
    dataset = SentinelPatchDataset(
        config["data"]["manifest"],
        split=args.split,
        scale=config["model"].get("scale", 4),
        caption_file=config["data"].get("captions"),
        caption_field=config["data"].get("caption_field", "caption"),
        caption_sampling="fixed",
        augment=False,
        random_degradation=False,
        degradation_seed=int(config["data"].get("degradation_seed", 0)),
        degradation_severity=config["data"].get("degradation_severity", "mild"),
        target_key=config["data"].get("target_key", "hr"),
        condition_key=config["data"].get("condition_key"),
        radiometric_calibration=config["data"].get("radiometric_calibration"),
        output_channels=config["model"].get("output_channels", 3),
        input_mode=config["data"].get("input_mode", "synthetic"),
    )
    if len(dataset) == 0:
        raise SystemExit(
            f"No patches found for split {args.split!r}. "
            "Check the manifest SAFE-prefix assignments."
        )
    loader = DataLoader(dataset, batch_size=1, shuffle=False)
    model = None
    if args.base_checkpoint:
        print(f"[baselines] loading checkpoint {args.base_checkpoint}", flush=True)
        model = GeoDiffGAN.from_config(config).to(device).eval()
        load_checkpoint(args.base_checkpoint, model, strict=False)
    if args.optional_metrics:
        print(
            "[baselines] --optional-metrics is deprecated; ERGAS, SAM, UIQI, "
            "and sCC are now computed automatically",
            flush=True,
        )
    print(
        "[baselines] remote-sensing metrics enabled: ERGAS, SAM, UIQI, sCC",
        flush=True,
    )
    totals: dict[str, defaultdict[str, float]] = {
        "bicubic": defaultdict(float),
        "base": defaultdict(float),
    }
    count = 0
    total = min(len(loader), args.limit) if args.limit is not None else len(loader)
    print(f"[baselines] plan patches={total}", flush=True)
    use_tqdm = args.progress == "tqdm"
    progress = tqdm(
        islice(loader, total),
        total=total,
        desc=f"baselines {args.split}",
        unit="patch",
        disable=not use_tqdm,
    )

    started = time.monotonic()
    with torch.no_grad():
        for batch in progress:
            lr = batch["lr"].to(device)
            lr_rgb = batch.get("lr_rgb", batch["lr"]).to(device)
            lr_rgb = lr_rgb[:, : int(config["model"].get("output_channels", 3))]
            raw_lr_rgb = batch.get("lr_raw_rgb", lr_rgb).to(device)
            clean_lr = batch["clean_lr"].to(device)
            hr = batch["hr"].to(device)
            degradation = batch["degradation"].to(device)
            valid_mask = (
                batch["valid_mask"].to(device).float()
                if "valid_mask" in batch
                else torch.ones_like(hr[:, :1])
            )
            valid_lr_mask = (
                batch["valid_mask_lr"].to(device).float()
                if "valid_mask_lr" in batch
                else None
            )
            predictions = {
                "bicubic": F.interpolate(
                    lr_rgb, size=hr.shape[-2:], mode="bicubic", align_corners=False
                ).clamp(0, 1)
            }
            if model is not None:
                with torch.autocast(
                    device_type=device.type,
                    dtype=torch.float16,
                    enabled=amp_enabled,
                ):
                    predictions["base"] = model.predict_base(lr).float()
            for name, prediction in predictions.items():
                values = basic_metrics(
                    prediction,
                    hr,
                    clean_lr,
                    degradation,
                    scale=config["model"].get("scale", 4),
                    severity=config["data"].get("degradation_severity", "mild"),
                    mask=valid_mask,
                    lr_mask=valid_lr_mask,
                )
                observed_noise = lr_rgb - clean_lr
                values["observed_lr_noise_l1"] = float(observed_noise.abs().mean())
                values["observed_lr_noise_to_signal"] = float(
                    observed_noise.abs().mean()
                    / clean_lr.abs().mean().clamp_min(1e-8)
                )
                values["radiometric_adjustment_l1"] = float(
                    (lr_rgb - raw_lr_rgb).abs().mean()
                )
                for metric, value in values.items():
                    totals[name][metric] += value
            count += 1
            progress.set_postfix(
                bicubic_psnr=f"{totals['bicubic']['psnr'] / count:.2f}",
                base_psnr=(
                    f"{totals['base']['psnr'] / count:.2f}"
                    if totals["base"]
                    else "n/a"
                ),
            )
            if args.progress == "compact":
                elapsed = time.monotonic() - started
                remaining = elapsed / count * (total - count)
                print(
                    f"[baselines] patch {count}/{total} "
                    f"bicubic_psnr={totals['bicubic']['psnr'] / count:.2f} "
                    f"elapsed={_duration(elapsed)} eta={_duration(remaining)}",
                    flush=True,
                )

    summary = {
        name: {metric: value / max(count, 1) for metric, value in metrics.items()}
        for name, metrics in totals.items()
        if metrics
    }
    summary["count"] = count
    summary["device"] = str(device)
    summary["amp"] = amp_enabled
    summary["remote_sensing_metrics"] = True
    summary["qnr_status"] = (
        "not_computed: QNR requires a compatible high-resolution panchromatic "
        "reference that is not present in the Landsat-Sentinel pairs"
    )
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", encoding="utf-8") as handle:
        json.dump(summary, handle, indent=2)
    print(f"[baselines] complete in {_duration(time.monotonic() - started)}", flush=True)
    print(summary, flush=True)


if __name__ == "__main__":
    main()
