from __future__ import annotations

import argparse
from pathlib import Path

import torch

from ..config import load_config
from ..data import SentinelPatchDataset
from ..diagnostics import DiagnosticRecorder
from ..models.system import GeoDiffGAN
from ..text import build_text_encoder
from ..training.checkpoint import load_checkpoint


def main() -> None:
    parser = argparse.ArgumentParser(description="Export GeoDiff-GAN tensor and visual diagnostics")
    parser.add_argument("--config", required=True)
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--split", default="test")
    parser.add_argument("--index", type=int, default=0)
    parser.add_argument("--mode", choices=("sr", "edit"), default="sr")
    parser.add_argument("--prompt")
    parser.add_argument("--steps", type=int, default=20)
    parser.add_argument(
        "--back-projection-steps",
        type=int,
        help="Override SR/edit back-projection iterations for ablation.",
    )
    parser.add_argument("--guidance", type=float, default=1.0)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--diffusion-every", type=int, default=5)
    parser.add_argument("--allow-nonfinite", action="store_true")
    parser.add_argument("--panel-size", type=int)
    parser.add_argument("--histogram-bins", type=int)
    parser.add_argument("--max-feature-channels", type=int)
    parser.add_argument(
        "--save-tensors",
        action=argparse.BooleanOptionalAction,
        default=None,
    )
    args = parser.parse_args()
    if args.back_projection_steps is not None and args.back_projection_steps < 0:
        parser.error("--back-projection-steps must be non-negative")

    config = load_config(args.config)
    debug_config = config.get("debug", {})
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = GeoDiffGAN.from_config(config).to(device).eval()
    load_checkpoint(args.checkpoint, model, strict=False)
    text_encoder = build_text_encoder(config).to(device).eval()
    dataset = SentinelPatchDataset(
        config["data"]["manifest"],
        split=args.split,
        scale=model.scale,
        caption_file=config["data"].get("captions"),
        caption_field=config["data"].get("caption_field", "caption"),
        caption_sampling="fixed",
        augment=False,
        random_degradation=False,
        degradation_seed=int(config["data"].get("degradation_seed", 0)),
        degradation_severity=config["data"].get("degradation_severity", "mild"),
        target_key=config["data"].get("target_key", "hr"),
        condition_key=config["data"].get("condition_key"),
        radiometric_calibration=config["data"].get("radiometric_calibration"),
        output_channels=config["model"].get("output_channels", 3),
        input_mode=config["data"].get("input_mode", "synthetic"),
    )
    if not dataset:
        raise RuntimeError(f"No samples found in split {args.split!r}")
    sample = dataset[args.index % len(dataset)]
    lr = sample["lr"].unsqueeze(0).to(device)
    clean_lr = sample["clean_lr"].unsqueeze(0).to(device)
    target = sample["hr"].unsqueeze(0).to(device)
    valid_mask = sample["valid_mask"].unsqueeze(0).to(device)
    valid_lr_mask = sample["valid_mask_lr"].unsqueeze(0).to(device)
    degradation = sample["degradation"].unsqueeze(0).to(device)
    prompt = args.prompt if args.prompt is not None else str(sample["caption"])
    context = text_encoder([prompt])
    null_context = text_encoder([""])
    recorder = DiagnosticRecorder(
        args.output,
        verbose=True,
        fail_on_nonfinite=not args.allow_nonfinite,
        panel_size=(
            args.panel_size
            if args.panel_size is not None
            else int(debug_config.get("panel_size", 320))
        ),
        histogram_bins=(
            args.histogram_bins
            if args.histogram_bins is not None
            else int(debug_config.get("histogram_bins", 64))
        ),
        max_feature_channels=(
            args.max_feature_channels
            if args.max_feature_channels is not None
            else int(debug_config.get("max_feature_channels", 16))
        ),
        save_tensors=(
            args.save_tensors
            if args.save_tensors is not None
            else bool(debug_config.get("save_tensors", False))
        ),
        max_saved_tensors=int(debug_config.get("max_saved_tensors", 32)),
    )
    generator = torch.Generator(device=device).manual_seed(args.seed)
    with torch.no_grad():
        output = model.sample(
            lr,
            context,
            degradation=degradation,
            projection_lr=clean_lr,
            mode=args.mode,
            sample_steps=args.steps,
            back_projection_steps=args.back_projection_steps,
            guidance_scale=args.guidance,
            null_context=null_context,
            generator=generator,
            diagnostics=recorder,
            diffusion_debug_interval=args.diffusion_every,
        )
    recorder.add_spatial_metrics(
        lr,
        output.base,
        output.residual,
        output.image,
        degradation,
        scale=model.scale,
        target=target,
        consistency_lr=clean_lr,
        degradation_severity=model.degradation_severity,
        valid_mask=valid_mask,
        valid_lr_mask=valid_lr_mask,
    )
    report = recorder.export(
        {
            "checkpoint": str(Path(args.checkpoint).resolve()),
            "config": str(Path(args.config).resolve()),
            "patch": str(sample["patch"]),
            "tile_id": str(sample["tile_id"]),
            "split": args.split,
            "index": args.index,
            "mode": args.mode,
            "prompt": prompt,
            "seed": args.seed,
            "steps": args.steps,
            "guidance": args.guidance,
            "architecture_notes": {
                "f32_and_f16_lr_features_are_recorded_but_not_consumed": True,
                "training_back_projection_steps_are_configurable": True,
                "inference_sr_mode_uses_three_back_projection_steps": True,
                "evidence_and_edit_policies_are_separate": True,
                "sr_abstains_toward_the_deterministic_base": True,
                "edit_residual_has_a_dedicated_decoder_head": True,
            },
        }
    )
    print(f"Diagnostic report: {report}")
    print(f"Share the complete directory: {Path(args.output).resolve()}")


if __name__ == "__main__":
    main()
